import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model

dataframe = pd.DataFrame()
dataframe["x"] = [5.1, 5.5, 5.9, 6.5, 6.8, 7.6, 8.3, 8.5, 9.1, 9.5]  # horas de estudo
dataframe["y"] = [2.0, 2.9, 4.0, 5.9, 6.0, 6.9, 8.0, 9.0, 9.9, 10.0] # pontuaçao alcançada
x_values = dataframe[["x"]]
y_values = dataframe[["y"]]

# Treinando o modelo
model = linear_model.LinearRegression()
model.fit(x_values, y_values)


# Exibindo os valores obtidos
print("Utilizando um modelo de Regressão Linear")
print("y = ax + b")
print("a = %.2f = inclinação da linha de tendência: " % model.coef_[0][0])
print("b = %.2f = ponto de interseção com o eixo y: " % model.intercept_[0])

# Utilizando o modelo
a = model.coef_[0][0]
b = model.intercept_[0]
horas = float(input("Quantas horas você pretende estudar? "))
notaPrevista = a * horas + b
print("A nossa previsão é de que sua nota será: %.1f"%notaPrevista)

# https://repl.it/@flaviusgorgonio/horasdeestudopy