import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model


#from sklearn.linear_model import LinearRegression
#import numpy as np
#from sklearn import datasets, linear_model
#from sklearn.metrics import mean_squared_error, r2_score



km_percorridos = [[8],[10],[12],[16],[20]]
calorias_queimadas = [[90],[112],[148],[189],[212]]

plt.figure()
plt.title("Quantidade de calorias consumidas por Km percorrido")
plt.xlabel("Km") 
plt.ylabel("Calorias") 
plt.plot(km_percorridos, calorias_queimadas, "k.") 
plt.axis([6, 25, 80, 220]) 
plt.grid(True) 
plt.show()
plt.savefig("desempenho.png")

dataframe = pd.DataFrame()
dataframe['x'] = [5.1, 5.5, 5.9, 6.5, 6.8, 7.6, 8.3, 8.5, 9.1, 9.5]  # horas de estudo
dataframe['y'] = [2.0, 2.9, 4.0, 5.9, 6.0, 6.9, 8.0, 9.0, 9.9, 10.0] # pontuaçao alcançada
x_values = dataframe[['x']]
y_values = dataframe[['y']]

model = linear_model.LinearRegression()
model.fit(x_values, y_values)

y_pred = model.predict(x_values)

df = pd.DataFrame({'Real': y_test, 'Predito': y_pred})
df1 = df.head(5)
df1.plot(kind='bar',figsize=(10,8))
plt.grid(which='major', linestyle='-', linewidth='0.5', color='green')
plt.grid(which='minor', linestyle=':', linewidth='0.5', color='black')
plt.show()
plt.savefig("curva.png")

#horas = str(model.predict([3.0])[0])
#print(horas)

#reg.predict(np.array([[3, 5]]))

#print("A quantidade de horas de estudo que você pode preciso para tirar 8.5 será: ",str(), "h")

#modelo = linear_model.LinearRegression()
#modelo.fit(km_percorridos, calorias_queimadas)
#print("A quantidade de km percorridos que você pode esperar gastar caso percorra 
#30km será: "+str(modelo.predict([30])[0]) +"Calorias")