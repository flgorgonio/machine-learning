import pandas
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC

url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/iris.csv"
#names = ["sepal-length", "sepal-width", "petal-length", "petal-width", "class"]
names = ["comp-sepala", "larg-sepala", "comp-petala", "larg-petala", "classe"]
dataset = pandas.read_csv(url, names=names)

# Conhecendo e analisando os dados
print("Dimensões da base de dados Iris (linhas, colunas)")
print(dataset.shape)
print()
print("Amostra dos dados")
print(dataset.head(10))
print(dataset.tail(10))
print()
print("Resumo estatístico")
print(dataset.describe())
print()
print("Distribuição dos dados em classes")
print(dataset.groupby('classe').size())

# Visualizando os dados
dataset.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
plt.show()
plt.savefig("boxplot.png")

dataset.hist()
plt.show()
plt.savefig("histogram.png")

scatter_matrix(dataset)
plt.show()
plt.savefig("scatter.png")

# Separando os dados em conjuntos de treinamento e de testes
vetor = dataset.values
X = vetor[:,0:4]
Y = vetor[:,4]
validation_size = 0.20
seed = 7
X_train, X_validation, Y_train, Y_validation = model_selection.train_test_split(X, Y, test_size=validation_size, random_state=seed)

seed = 7
scoring = 'accuracy'

# Algoritmos e modelos
models = []
models.append(('LR', LogisticRegression(solver='liblinear', multi_class='ovr')))
models.append(('LDA', LinearDiscriminantAnalysis()))
models.append(('KNN', KNeighborsClassifier()))
models.append(('CART', DecisionTreeClassifier()))
models.append(('NB', GaussianNB()))
models.append(('SVM', SVC(gamma='auto')))

# Avaliação de cada modelo
results = []
names = []
print()
print("Avaliação dos modelos testados")
for name, model in models:
  kfold = model_selection.KFold(n_splits=10, random_state=seed)
  cv_results = model_selection.cross_val_score(model, X_train, Y_train, cv=kfold, scoring=scoring)
  results.append(cv_results)
  names.append(name)
  msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
  print(msg)


# Comparando visualmente os algoritmos
fig = plt.figure()
fig.suptitle('Comparação dos Algoritmos')
ax = fig.add_subplot(111)
plt.boxplot(results)
ax.set_xticklabels(names)
plt.show()
plt.savefig("accuracy.png")


# Matriz de confusão e resultados do KNN
knn = KNeighborsClassifier()
knn.fit(X_train, Y_train)
predictions = knn.predict(X_validation)
print()
print("Acurácia do KNN")
print(accuracy_score(Y_validation, predictions))
print()
print("Matriz de confusão do KNN")
print(confusion_matrix(Y_validation, predictions))
print()
print("Precisão do KNN")
print(classification_report(Y_validation, predictions))

# Matriz de confusão e resultados do SVM
svc = SVC(gamma='auto')
svc.fit(X_train, Y_train)
predictions = svc.predict(X_validation)
print()
print("Acurácia do SVM")
print(accuracy_score(Y_validation, predictions))
print()
print("Matriz de confusão do SVM")
print(confusion_matrix(Y_validation, predictions))
print()
print("Precisão do SVM")
print(classification_report(Y_validation, predictions))

#https://repl.it/@flaviusgorgonio/irispy